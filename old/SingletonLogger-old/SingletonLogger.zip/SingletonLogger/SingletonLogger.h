#pragma once
/////////////////////////////////////////////////////////////////////
// SingletonLogger.h - demonstrates logging to multiple streams    //
//                                                                 //
// Jim Fawcett, CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
*  What's being demonstrated:
*  - std::ostream is a base class for output streams that include
*    std::ofstream, used to write to files, and std::ostringstream,
*    used to write to in-memory strings using the std::ostream
*    interface.
*  - The most fundamental principle in Object Oriented Design is the
*    Liskov Substitution Principle (LSP), which states:
*
*      Functions that accept base class pointers or references also
*      accept pointers or references to any class that derives from
*      the base, and can be used by the function without any special
*      knowledge beyond the base class interface.
*
*  That means that we can register standard streams that derive from
*  std::ostream with a logger if its add function accepts pointers or
*  references to the base std::ostream class.
*/
#include <iostream>
#include <fstream>
#include <sstream>   // defines std::getline(std::istream, std::string)
#include <vector>
#include <thread>
#include <mutex>
#include <memory>
#include "../CppDateTime/DateTime.h"

namespace CodeUtilities
{
  class NoLock
  {
  public:
    void lock() {}
    void unlock() {}
  };

  class Lock
  {
  public:
    Lock() {}
    Lock(const Lock&) = delete;
    Lock& operator=(const Lock&) = delete;
    ~Lock()
    {
      if (locked_)
      {
        //std::cout << "\n  unlocking in Lock destructor";
        mtx_.unlock();
      }
    }
    void lock()
    {
      mtx_.lock();
      locked_ = true;
    }
    void unlock()
    {
      mtx_.unlock();
      locked_ = false;
    }
    bool isLocked()
    {
      return locked_;
    }
  private:
    bool locked_ = false;
    std::recursive_mutex mtx_;
  };

  ///////////////////////////////////////////////////////////////////
  // Logger class
  // - Thread-safe singleton
  // - supports logging to multiple streams with a single write
  // - int template parameter supports multiple logs shared by
  //   the value of that parameter.
  // - Locker template parameter supports removing locking in
  //   single-threaded environments.

  template<int Category, typename Locker>
  class Logger
  {
    using Streams = std::vector<std::ostream*>;
    using Terminator = std::string;

  public:
    Logger(const Logger<Category, Locker>&) = delete;
    Logger<Category, Locker>& operator=(const Logger<Category, Locker>&) = delete;

    void addStream(std::ostream* pStream)
    {
      streams_.push_back(pStream);
    }
    bool removeStream(std::ostream* pStream)
    {
      Streams::iterator iter = std::find(streams_.begin(), streams_.end(), pStream);
      if (iter != streams_.end())
      {
        streams_.erase(iter);
        return true;
      }
      return false;
    }
    void setTerminator(const Terminator& term) { trm_ = term; }

    void writeHead(const std::string& msg)
    {
      std::string headerMsg = msg + " : ";
      headerMsg += DateTime().now() + trm_;
      for (auto pStrm_ : streams_)
      {
        *pStrm_ << headerMsg;
      }
    }
    void write(const std::string& text)
    {
      std::string logMsg = text + trm_;
      for (auto pStrm_ : streams_)
        *pStrm_ << logMsg;
    }
    void writeTail(const std::string& msg = "end of log")
    {
      for (auto pStrm_ : streams_)
        *pStrm_ << msg.c_str();
    }
    // Thread-safe singleton access:
    // - Does not attempt to improve performance by double-check locking
    // - That may fail occasionally, in C++, due to caching of instance_.
    // - Since accesses are rare, usually only a very few times per
    //   execution, performance degradation is very small.
    
    static Logger<Category, Locker>* getInstance()
    {
      locker_.lock();
      if (instance_ == nullptr)
      {
        instance_ = new Logger<Category, Locker>();
      }
      locker_.unlock();
      return instance_;
    }
  private:
    Logger()
    {
      //locker_.unlock();
      addStream(&std::cout);
    }
    static Locker locker_;
    static Logger<Category, Locker>* instance_;
    Streams streams_;
    Terminator trm_ = "\n  ";  // default item terminator
  };

  template<int Category, typename Locker>
  Locker Logger<Category, Locker>::locker_;

  template<int Category, typename Locker>
  Logger<Category, Locker>* Logger<Category, Locker>::instance_ = nullptr;


  ///////////////////////////////////////////////////////////////////
  // displayFileContents function
  // - attempts to open fileSpec
  // - if successful, reads lines until ostream.good() returns false
  // - displays each line on the console

  inline bool displayFileContents(
    const std::string& msg,        // msg to display first
    const std::string& fileSpec,   // path to file
    std::ostream& out = std::cout  // stream to write output
  )
  {
    if (msg.size() > 0)
    {
      out << "\n\n  " << msg.c_str();
    }
    std::ifstream inFileStrm_(fileSpec);
    if (!inFileStrm_.good())
    {
      out << "\n  can't open " << fileSpec.c_str() << "\n";
      return false;
    }
    while (inFileStrm_.good())
    {
      std::string line;
      std::getline(inFileStrm_, line);
      out << "\n" << line.c_str();
    }
    return true;
  }
}